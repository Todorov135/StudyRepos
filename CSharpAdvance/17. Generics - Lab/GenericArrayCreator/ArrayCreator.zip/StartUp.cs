﻿using System;

namespace GenericArrayCreator
{
    public class StartUp
    {
        static void Main( )
        {
            var strings = ArrayCreator.Create(10, 20);
            

        }
    }
}
