﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models.Interfaces
{
    public interface IEmptyBus
    {
        public string DriveEmpty(double distance);
    }
}
