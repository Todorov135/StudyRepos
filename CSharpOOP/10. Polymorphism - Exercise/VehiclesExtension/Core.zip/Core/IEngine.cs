﻿namespace Vehicles.Core
{
    public interface IEngine
    {
        void Start();
    }
}
