﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Core
{
    public interface IEngine
    {
        void Start();
    }
}
