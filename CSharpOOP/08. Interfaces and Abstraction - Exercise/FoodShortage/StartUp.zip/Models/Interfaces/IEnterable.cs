﻿namespace BorderControl.Models.Interfaces
{
    public interface IEnterable
    {
        public string Id { get;}
    }
}
