﻿namespace BorderControl.Models.Interfaces
{
    public interface IBirthdate
    {
        public string Birthdate { get;}
    }
}
