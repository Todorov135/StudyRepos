﻿namespace Telephony.Models.Interface
{
    public interface IBrowseable
    {
        string BrowseURL(string url);
    }
}
