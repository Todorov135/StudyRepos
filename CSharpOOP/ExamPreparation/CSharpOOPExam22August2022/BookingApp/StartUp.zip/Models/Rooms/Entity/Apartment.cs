﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingApp.Models.Rooms.Entity
{
    public class Apartment : Room
    {
        public Apartment() : base(6)
        {
        }
    }
}
