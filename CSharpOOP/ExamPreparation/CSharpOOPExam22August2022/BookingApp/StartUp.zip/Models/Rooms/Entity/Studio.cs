﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookingApp.Models.Rooms.Entity
{
    public class Studio : Room
    {
        public Studio() : base(4)
        {
        }
    }
}
