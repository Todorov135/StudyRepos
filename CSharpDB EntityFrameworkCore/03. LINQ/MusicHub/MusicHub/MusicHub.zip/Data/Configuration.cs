﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-1JGF0DM\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
